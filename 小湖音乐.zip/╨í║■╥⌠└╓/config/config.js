// 配置服务器相关信息
export default {
  host: 'http://127.0.0.1:3000',
}